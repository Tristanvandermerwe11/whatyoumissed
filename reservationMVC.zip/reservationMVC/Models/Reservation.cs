﻿namespace reservationMVC.Models
{
    public class Reservation
    {

        public int id { get; set; }
        public string custName { get; set; }

        public string phoneNumber { get; set; }

        public DateTime resDate { get; set; }

        public int numGuests { get; set; }

        public string tableType {  get; set; }  

        public string specialRequest { get; set; }



    }
}
