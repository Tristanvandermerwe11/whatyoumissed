﻿using Microsoft.AspNetCore.Mvc;
using reservationMVC.Models;
using System.Reflection.Metadata.Ecma335;
namespace reservationMVC.Controllers
{
    public class ReservationsController : Controller
    {
        private static List<Reservation> reservations = new List<Reservation>()
        {

        new Reservation
            {
            id =1,
            custName = "Joe Soap",
                phoneNumber= "0821112222",
                resDate = new DateTime(2023, 8, 25, 19, 0, 0),
            numGuests = 4,
            tableType = "Indoor",
            specialRequest = "Birthday Dinner"

            },
         new Reservation
            {
            id =2,
            custName = "Jane Doe",
                phoneNumber= "076334444",
                resDate = new DateTime(2023, 8, 26, 20, 30, 0),
            numGuests = 2,
            tableType = "Outdoor",
            specialRequest = "Booth Seat By The Window"

            }
        };






        public IActionResult Index()
        {
            return View(reservations);
        }

        public IActionResult Details(int id)
        {
            var res = reservations.FirstOrDefault(r => r.id == id);

            if (res == null)
            {
                return NotFound();

            }

            return View(res);
        }
        //restful web service
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        //to 
        [HttpPost]
        public IActionResult Create(Reservation reservation)
        {

            //LINQ to generate a new ID for us 
            reservation.id = reservations.Any()
                ? reservations.Max(r => r.id) + 1
                : 1;


            reservations.Add(reservation);
            return RedirectToAction("Index");
        }



        [HttpGet]
        public IActionResult Edit(int id)
        {
            var res = reservations.FirstOrDefault(r => r.id == id);
            if (res == null)
            {
                return NotFound();
            }
            return View(res);
        }


        [HttpPost]
        public IActionResult Edit(int id, Reservation updateRes)
        {
            if (id != updateRes.id)
            {
                return NotFound();
            }

            var res = reservations.FirstOrDefault(r => r.id == id);

            if (res == null)
            {
                return NotFound();
            }


            res.custName = updateRes.custName;
            res.phoneNumber = updateRes.phoneNumber;
            res.resDate = updateRes.resDate;
            res.numGuests = updateRes.numGuests;
            res.tableType = updateRes.tableType;
            res.specialRequest = updateRes.specialRequest;

            return RedirectToAction("Index");
        }



        [HttpPost]

        public IActionResult Delete(int id)
        {
            var res = reservations.FirstOrDefault(r => r.id == id);
            if (res == null)
            {
                return NotFound();
            }
            reservations.Remove(res);

            return RedirectToAction("Index");




        }




    }
}
